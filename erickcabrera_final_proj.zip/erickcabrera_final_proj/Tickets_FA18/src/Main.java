/*
 * Erick Cabrera
 * Dec. 9, 2018
 * Main.java
 * Tickets_FA18
 * 
 * Purpose: The purpose of this program is
 * to create a support ticketing system that
 * allows you to create, view, update, and 
 * delete tickets.
 */

public class Main{

    public static void main(String[] args) {
        new Login();
    }
}