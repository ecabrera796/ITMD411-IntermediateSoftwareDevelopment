/*
 * Erick Cabrera
 * Oct. 5, 2018
 * Client.java
 * Lab 02
 */

//read file detail
public abstract class Client {
    public abstract void readData();
    public abstract void processData();
    public abstract void printData();
}